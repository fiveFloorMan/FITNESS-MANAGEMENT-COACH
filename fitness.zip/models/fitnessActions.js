"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.FitnessActionModel = exports.TrainingPart = void 0;
const mongoose_1 = __importDefault(require("mongoose"));
var TrainingPart;
(function (TrainingPart) {
    TrainingPart["CHEST"] = "chest";
    TrainingPart["BACK"] = "Back";
    TrainingPart["SHOURLDER"] = "shoulder";
    TrainingPart["TRICEPS"] = "triceps";
    TrainingPart["BICEPS"] = "biceps";
    TrainingPart["ABS"] = "abs";
    TrainingPart["HIPS"] = "hips";
    TrainingPart["THIGH"] = "thigh";
    TrainingPart["CALF_MUSCLE"] = "calf muscle";
})(TrainingPart = exports.TrainingPart || (exports.TrainingPart = {}));
const FitnessActionSchema = new mongoose_1.default.Schema({
    trainingName: {
        type: String,
        required: true,
    },
    trainingPart: {
        type: String,
        required: true,
    }
});
exports.FitnessActionModel = mongoose_1.default.model('FitnessAction', FitnessActionSchema);
