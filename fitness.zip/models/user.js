"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserModel = exports.IsAdminLevel = void 0;
const mongoose_1 = __importDefault(require("mongoose"));
var IsAdminLevel;
(function (IsAdminLevel) {
    IsAdminLevel["MEMBER"] = "member";
    IsAdminLevel["ADMIN"] = "admin";
})(IsAdminLevel = exports.IsAdminLevel || (exports.IsAdminLevel = {}));
const UserSchema = new mongoose_1.default.Schema({
    name: {
        type: String,
        required: true,
    },
    email: {
        type: String,
        required: true,
        unique: true,
    },
    password: {
        type: String,
        required: true,
    },
    gender: {
        type: Boolean,
        required: true
    },
    height: {
        type: Number,
        required: true
    },
    weight: {
        type: Number,
        required: true
    },
    isAdmin: {
        type: String,
        required: true,
    }
});
exports.UserModel = mongoose_1.default.model('User', UserSchema);
