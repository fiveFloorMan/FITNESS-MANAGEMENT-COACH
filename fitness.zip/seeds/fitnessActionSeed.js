"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = __importDefault(require("mongoose"));
require('dotenv').config();
const db_connection_1 = require("../db/db.connection");
const fitnessActions_1 = require("../models/fitnessActions");
const fitnessActionSeed_json_1 = __importDefault(require("./fitnessActionSeed.json"));
(async () => {
    await (0, db_connection_1.connectDB)();
    try {
        for (const seed of fitnessActionSeed_json_1.default) {
            const { trainingName, trainingPart } = seed;
            const singleSeed = new fitnessActions_1.FitnessActionModel({
                // 因為是種子資料所以不會限制trainingPart的type範圍
                trainingName: trainingName,
                trainingPart: trainingPart
            });
            await singleSeed.save();
        }
        console.log('Fitness-Action-Seed is successfully Create.');
    }
    catch (error) {
        console.error('Error was happened when build Fitness-Action-Seed', error);
    }
    finally {
        mongoose_1.default.connection.close();
    }
})();
