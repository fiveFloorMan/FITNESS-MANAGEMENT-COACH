"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.verifyToken = exports.signToken = void 0;
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
// 簽發token
const signToken = (payload, secret, expiresIn) => {
    return new Promise((resolve, reject) => {
        jsonwebtoken_1.default.sign(payload, secret, { expiresIn }, (error, token) => {
            if (error) {
                reject(error);
            }
            else {
                resolve(token);
                console.log(token);
            }
        });
    });
};
exports.signToken = signToken;
// 驗證token
const verifyToken = (token, secret) => {
    return new Promise((resolve, reject) => {
        jsonwebtoken_1.default.verify(token, secret, (error, decoded) => {
            if (error) {
                reject(error);
            }
            else {
                return resolve(decoded);
            }
        });
    });
};
exports.verifyToken = verifyToken;
