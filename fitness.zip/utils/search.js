"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.findFitnessAction = exports.findUser = void 0;
const user_1 = require("../models/user");
const fitnessActions_1 = require("../models/fitnessActions");
const findUser = (userId) => {
    return user_1.UserModel.findById(userId)
        .exec() // 確保是查詢promise物件
        .then((user) => {
        if (user) {
            return user;
        }
        else {
            throw new Error('User not found.');
        }
    });
};
exports.findUser = findUser;
const findFitnessAction = (trainingItemId) => {
    return fitnessActions_1.FitnessActionModel.findById(trainingItemId)
        .exec() // 確保是查詢promise物件
        .then((trainingItem) => {
        if (trainingItem) {
            return trainingItem;
        }
        else {
            throw new Error('Training Item not found.');
        }
    });
};
exports.findFitnessAction = findFitnessAction;
