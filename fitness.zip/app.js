"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const routesIndex_1 = __importDefault(require("./routes/routesIndex"));
const db_connection_1 = require("./db/db.connection");
const body_parser_1 = __importDefault(require("body-parser"));
if (process.env.NODE_ENV !== 'production') {
    require('dotenv').config();
}
const app = (0, express_1.default)();
const PORT = 3000;
(0, db_connection_1.connectDB)();
app.use(body_parser_1.default.urlencoded({ extended: false }));
app.use(body_parser_1.default.json());
app.use('/api', routesIndex_1.default);
app.listen(PORT, () => {
    console.log(`WEB IS RUNNING!`);
});
