"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.RecordController = void 0;
const singleTraining_1 = require("../models/singleTraining");
const token_1 = require("../utils/token");
const search_1 = require("../utils/search");
const mongoose_1 = __importDefault(require("mongoose"));
exports.RecordController = {
    getAllRecord: async (req, res) => {
        var _a;
        try {
            const token = (_a = req.headers.authorization) === null || _a === void 0 ? void 0 : _a.split(' ')[1];
            const decodedToken = await (0, token_1.verifyToken)(token, process.env.JWT_SECRET);
            const allRecord = await singleTraining_1.SingleTrainingModel.aggregate([
                {
                    $match: {
                        userId: new mongoose_1.default.Types.ObjectId(decodedToken.sub)
                    }
                }
            ]);
            if (!allRecord || allRecord.length === 0) {
                return res.status(200).json({
                    message: '目前沒有任何紀錄, 現在就馬上開始創建一個新的吧!'
                });
            }
            return res.status(200).json({
                message: 'All records feteched successfully!',
                allRecord
            });
        }
        catch (error) {
            return res.status(500).json({
                message: 'Failed to fetch records!',
                error: error.message,
            });
        }
    },
    createRecord: async (req, res) => {
        var _a;
        try {
            const token = (_a = req.headers.authorization) === null || _a === void 0 ? void 0 : _a.split(' ')[1];
            const decodedToken = await (0, token_1.verifyToken)(token, process.env.JWT_SECRET);
            const user = await (0, search_1.findUser)(decodedToken.sub);
            const trainingItem = await (0, search_1.findFitnessAction)(req.body.trainingItemId);
            const singleTraining = new singleTraining_1.SingleTrainingModel({
                trainingDate: req.body.trainingDate,
                trainingItemId: trainingItem,
                userId: user,
                reps: req.body.reps,
                sets: req.body.sets,
                restTime: req.body.restTime,
                weightTraining: req.body.weightTraining,
            });
            await singleTraining.save();
            return res.status(201).json({
                message: 'Single training created successfully!',
                singleTraining,
            });
        }
        catch (error) {
            return res.status(500).json({
                message: 'Failed to create single training!',
                error: error.message,
            });
        }
    },
    updateRecord: async (req, res) => {
        try {
            const trainingItem = await (0, search_1.findFitnessAction)(req.body.trainingItemId);
            const updatedRecord = await singleTraining_1.SingleTrainingModel.findByIdAndUpdate(req.params.id, {
                trainingDate: req.body.trainingDate,
                trainingItemId: trainingItem,
                reps: req.body.reps,
                sets: req.body.sets,
                restTime: req.body.restTime,
                weightTraining: req.body.weightTraining,
            }, { new: true });
            return res.status(200).json({
                message: "Record updated successfully!",
                updatedRecord
            });
        }
        catch (error) {
            return res.status(500).json({
                message: "Failed to update record!",
                error: error.message,
            });
        }
    },
    deleteRecord: async (req, res) => {
        try {
            await singleTraining_1.SingleTrainingModel.deleteOne({ _id: req.params.id });
            return res.status(200).json({ message: "Record deleted successfully!" });
        }
        catch (error) {
            return res.status(500).json({
                message: "Failed to deleted record!",
                error: error.message
            });
        }
    }
};
