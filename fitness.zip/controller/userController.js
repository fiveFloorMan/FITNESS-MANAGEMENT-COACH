"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserController = void 0;
const passport_1 = __importDefault(require("passport"));
const bcrypt_1 = __importDefault(require("bcrypt"));
const token_1 = require("../utils/token");
const user_1 = require("../models/user");
const user_2 = require("../models/user");
require("../config/passport");
exports.UserController = {
    userLogin: (req, res) => {
        passport_1.default.authenticate('local', { session: false }, async (error, user, info) => {
            if (error) {
                return res.status(500).json({ error: error.message });
            }
            if (!user) {
                return res.status(401).json({ error: info.message });
            }
            const token = await (0, token_1.signToken)({ sub: user.id }, process.env.JWT_SECRET, '24h');
            return res.json({ token });
            // 給予前端token之後讓前端自行處理跳轉
        })(req, res);
    },
    userRegister: async (req, res, next) => {
        const { name, email, password, gender, height, weight, isAdmin } = req.body;
        try {
            const existingUser = await user_1.UserModel.findOne({ email });
            if (existingUser) {
                return res.status(409).json({ error: 'User already exists' });
            }
            const saltRounds = 10;
            const hashedPassword = await bcrypt_1.default.hash(password, saltRounds);
            const user = new user_1.UserModel({ name, email, password: hashedPassword, gender, height, weight, isAdmin });
            if (!Object.values(user_2.IsAdminLevel).includes(user.isAdmin)) {
                return res.status(400).json({ error: 'Level error.' });
            }
            const userTypeCheck = user;
            if (userTypeCheck) {
                await user.save();
            }
            return res.json({ message: `${user.name} is created successfully.` });
        }
        catch (_a) {
            return next(Error);
        }
    }
};
